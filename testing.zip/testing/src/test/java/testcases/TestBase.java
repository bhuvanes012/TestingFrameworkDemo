package testcases;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;

import io.github.bonigarcia.wdm.WebDriverManager;
import utlity.ExtentManager;
import utlity.WebDriverManagerUtil; 

public class TestBase {
    public ThreadLocal<WebDriver>  driver= new ThreadLocal<WebDriver>();
    protected ThreadLocal<ExtentTest> ExtentTest = new ThreadLocal<ExtentTest>();
    @BeforeSuite
    public void beforeSuite() {
    	ExtentManager.getExtent();
    }

    @BeforeMethod(alwaysRun = true)
    public void setUp( Method method) {
    	if (driver.get() == null) {
			 WebDriverManager.edgedriver().setup();
			 driver.set(new EdgeDriver());
			 driver.get().manage().window().maximize();
		}
       
        ExtentTest.set(ExtentManager.createTest(method.getName()));
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
    	if (driver.get() != null) {
			driver.get().quit();
			driver.set( null);
		}
    	 if (result.getStatus() == ITestResult.FAILURE) {
    		 ExtentTest.get().fail("Test failed",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenshot(driver.get())).build());
    		 
         }
        ExtentManager.flushReport();
    }
    
    public void takeScreenShot() {

    	 ExtentTest.get().pass("Test passed",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenshot(driver.get())).build());
    }
    private static String captureScreenshotAsBase64(WebDriver driver) {
        // Capture screenshot and return as Base64
        TakesScreenshot ts = (TakesScreenshot) driver;
        byte[] screenshot = ts.getScreenshotAs(OutputType.BYTES);
        return Base64.getEncoder().encodeToString(screenshot);
    }
    private static String takeScreenshot(WebDriver driver) {
        // Generate a timestamped file name
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fileName = "screenshot_" + timestamp + ".png";
        String filePath = "./pic/" + fileName; // Update with your destination path

        // Capture screenshot and save to specified path
        TakesScreenshot ts = (TakesScreenshot) driver;
        File screenshot = ts.getScreenshotAs(OutputType.FILE);
        try {
			FileUtils.copyFile(screenshot, new File(filePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        return filePath; // Return the path of the saved screenshot
    }
    
    public static void sleep(int time) {
    	try {
    		Thread.sleep(time);
    	}catch (Exception e) {
			// TODO: handle exception
		}
    }
}