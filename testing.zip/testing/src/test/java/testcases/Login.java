package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import utlity.WebDriverManagerUtil;

public class Login extends TestBase {
	String useName = "user-name";
	String passWord = "password";
	String loginButton = "login-button";
	String ErrorMsg	=	"//*[@data-test='error']";

	
	@Test
    public void openGoogleTest() {
        driver.get().get("https://www.saucedemo.com/v1/");
        ExtentTest.get().info("Navigated to Google");
        String pageTitle = driver.get().getTitle();
        ExtentTest.get().info("Page title is: " + pageTitle);
        takeScreenShot();
        driver.get().findElement(By.id(useName)).sendKeys("Test");
        driver.get().findElement(By.id(passWord)).sendKeys("password");
        
        driver.get().findElement(By.id(loginButton)).click();
        //sleep(3000);
        String errorMsg = driver.get().findElement(By.xpath(ErrorMsg)).getText();
        System.out.println("error msg "+errorMsg);
        
    }
	
}
